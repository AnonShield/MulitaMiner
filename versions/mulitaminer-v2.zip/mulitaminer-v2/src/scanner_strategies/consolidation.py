from typing import List, Dict

def deduplicate_by_name(vulnerabilities: list, field: str = "Name") -> list:
    """
    Remove duplicatas baseando-se no campo especificado, mantendo a vulnerabilidade mais completa (mais campos preenchidos).
    """
    if not vulnerabilities:
        return []
    from collections import defaultdict
    grouped = defaultdict(list)
    for v in vulnerabilities:
        key = v.get(field, None) if isinstance(v, dict) else None
        grouped[key].append(v)
    result = []
    for group in grouped.values():
        if len(group) == 1:
            result.append(group[0])
        else:
            # Keep the most complete (more non-empty fields)
            def count_filled_fields(vuln):
                return sum(1 for k, val in vuln.items() if val not in [None, '', [], {}, 0])
            most_complete = max(group, key=count_filled_fields)
            result.append(most_complete)
    return result

def generate_consolidation_log(strategy_report: dict = None, description_filtering_removed: int = 0, 
                              all_groups: dict = None, vulnerabilities_input: int = 0,
                              vulnerabilities_after_strategy: int = 0, vulnerabilities_final: int = 0) -> str:
    """
    Gera um log modular e legível de consolidação.
    
    Args:
        strategy_report: Dict retornado por strategy.get_consolidation_report()
        description_filtering_removed: Quantas vulns foram removidas pela filtragem de description
        all_groups: Dict com grupos de vulnerabilidades para detalhes
        vulnerabilities_input: Total na entrada
        vulnerabilities_after_strategy: Total após strategy processing
        vulnerabilities_final: Total final (após filtragem)
    
    Returns:
        String com o log formatado
    """
    lines = []
    lines.append("=" * 70)
    lines.append("CONSOLIDATION & DEDUPLICATION REPORT")
    lines.append("=" * 70)
    lines.append("")
    
    if strategy_report:
        lines.append(f"Strategy: {strategy_report.get('strategy_name', 'Unknown')}")
        lines.append(f"Description: {strategy_report.get('description', 'N/A')}")
        lines.append("")
        
        lines.append(f"INPUT VULNERABILITIES: {vulnerabilities_input}")
        lines.append("")
        
        lines.append("PROCESSING STAGE 1: Strategy-Specific Consolidation")
        lines.append(f"  Result: {vulnerabilities_after_strategy} vulnerabilities")
        lines.append(f"  Removed: {vulnerabilities_input - vulnerabilities_after_strategy} ({strategy_report.get('reason', 'consolidation')})")
        if strategy_report.get('note'):
            lines.append(f"  Note: {strategy_report['note']}")
        lines.append("")
        
        if description_filtering_removed > 0:
            lines.append("PROCESSING STAGE 2: Description Validation Filter")
            lines.append(f"  Removed: {description_filtering_removed} (empty or invalid descriptions)")
            lines.append(f"  Result: {vulnerabilities_final} vulnerabilities")
            lines.append("")
        
        lines.append(f"OUTPUT FINAL: {vulnerabilities_final} vulnerabilities (valid & saved)")
    else:
        lines.append(f"INPUT: {vulnerabilities_input} vulnerabilities")
        lines.append(f"OUTPUT: {vulnerabilities_final} vulnerabilities")
    
    lines.append("")
    lines.append("=" * 70)
    
    log_text = "\n".join(lines)
    
    # Adiciona detalhes dos grupos se fornecidos
    if all_groups:
        log_text += "\nDETAIL: Vulnerability Groups\n"
        log_text += "-" * 70 + "\n"
        for idx, (key, group) in enumerate(all_groups.items(), 1):
            log_text += f"Group {idx}: Key = {repr(key)}\n"
            log_text += f"  Total vulnerabilities in group: {len(group)}\n"
            for i, v in enumerate(group, 1):
                nome = v.get('Name', 'NO NAME')
                porta = v.get('port', '')
                protocolo = v.get('protocol', '')
                severidade = v.get('severity', '')
                desc = v.get('description', '')
                log_text += f"    {i}. Name: {nome}\n"
                log_text += f"       Port: {porta} | Protocol: {protocolo} | Severity: {severidade}\n"
                if desc:
                    if isinstance(desc, list):
                        desc = ' '.join([str(d) for d in desc if d])
                    desc = str(desc).strip().replace('\n', ' ')
                    log_text += f"       Description: {desc[:150]}{'...' if len(desc)>150 else ''}\n"
                else:
                    log_text += f"       Description: (empty)\n"
            log_text += "\n"
        log_text += "=" * 70 + "\n"
    
    return log_text


def central_custom_allow_duplicates(vulnerabilities: list, profile_config: dict = None, allow_duplicates = True, custom_strategy: str = None, output_file: str = None) -> list:
    """
    Pipeline central para deduplicação/consolidação:
    - Sempre consulta registry.py para estratégia customizada.
    - allow_duplicates=True/False: passado para a estratégia, que decide o comportamento.
    - Se não houver estratégia, usa deduplicate_by_name padrão.
    Gera logs de merge, deduplicação e removed para todos os scanners.
    """
    from .registry import get_strategy
    import os
    import json
    source = None
    if vulnerabilities and isinstance(vulnerabilities[0], dict):
        source = vulnerabilities[0].get('source', None)
    if not source and profile_config and 'reader' in profile_config:
        source = profile_config['reader']
    strategy = get_strategy(source) if source else None
    # Always use the explicit output_file
    if not output_file and profile_config and 'output_file' in profile_config:
        output_file = profile_config['output_file']
    if not output_file:
        output_file = 'output.json'
    # Use the full path of output file
    merge_log_path = os.path.splitext(output_file)[0] + '_merge_log.txt'
    dedup_log_path = os.path.splitext(output_file)[0] + '_deduplication_log.txt'
    removed_log_path = os.path.splitext(output_file)[0] + '_removed_log.txt'
    # Deduplication/consolidation
    if strategy and hasattr(strategy, 'vulnerability_processing_logic'):
        print(f"[DEDUPLICATION] allow_duplicates mode: {'True' if allow_duplicates else 'False'} (custom: {source})")
        
        # Captura estado ANTES
        input_count = len(vulnerabilities)
        
        # Executa strategy
        result = strategy.vulnerability_processing_logic(vulnerabilities, allow_duplicates, profile_config)
        after_strategy_count = len(result)
        
        # After deduplication, filter by valid description
        def has_valid_description(vuln):
            desc = vuln.get("description")
            if not desc:
                return False
            if isinstance(desc, list):
                return any(str(d).strip() for d in desc)
            return bool(str(desc).strip())
        valid_result = []
        removed = []
        for v in result:
            if has_valid_description(v):
                valid_result.append(v)
            else:
                removed.append(v)
        # Save removed items log
        if removed:
            with open(removed_log_path, 'w', encoding='utf-8') as f:
                f.write(f"# LOG OF REMOVED VULNERABILITIES (missing valid description)\n\n")
                for idx, v in enumerate(removed, 1):
                    f.write(f"Removed {idx}:\n")
                    f.write(json.dumps(v, ensure_ascii=False, indent=2))
                    f.write("\n---\n")
            print(f"[DEDUPLICATION] Removed items log: {removed_log_path}")
        result = valid_result
        
        # Get strategy report for better logging
        strategy_report = None
        if hasattr(strategy, 'get_consolidation_report'):
            strategy_report = strategy.get_consolidation_report(
                input_count=input_count,
                output_count=after_strategy_count,
                removed=input_count - after_strategy_count
            )
        
        # Reconstruir agrupamento para detalhes do log
        from collections import defaultdict
        grouped = defaultdict(list)
        for v in result:
            name = v.get('Name', '').strip()
            port = v.get('port')
            protocol = v.get('protocol')
            if name == 'Services':
                def make_hashable(val):
                    if isinstance(val, list):
                        return tuple(val)
                    elif isinstance(val, dict):
                        return tuple(sorted(val.items()))
                    else:
                        return val
                key = tuple(sorted((k, make_hashable(vv)) for k, vv in v.items()))
            else:
                key = (name, port, protocol)
            grouped[key].append(v)
        
        # Generate modular log using new function
        log_content = generate_consolidation_log(
            strategy_report=strategy_report,
            description_filtering_removed=len(removed),
            all_groups=grouped,
            vulnerabilities_input=input_count,
            vulnerabilities_after_strategy=after_strategy_count,
            vulnerabilities_final=len(result)
        )
        
        # Save consolidation log
        with open(dedup_log_path, 'w', encoding='utf-8') as f:
            f.write(log_content)
        print(f"[DEDUPLICATION] Consolidation log saved to: {dedup_log_path}")
        
        return result
    # fallback: simple deduplication
    print(f"[DEDUPLICATION] allow_duplicates mode: {'True' if allow_duplicates else 'False'} (default)")
    field = 'Name'
    if profile_config and 'consolidation_field' in profile_config:
        field = profile_config['consolidation_field']
    
    input_count = len(vulnerabilities)
    
    if allow_duplicates is True:
        result = vulnerabilities
        dedup_reason = "allow_duplicates=True (no deduplication)"
    else:
        result = deduplicate_by_name(vulnerabilities, field)
        dedup_reason = f"deduplicated by {field}"
    
    after_strategy_count = len(result)
    
    # Criar report para fallback
    fallback_report = {
        'strategy_name': 'Default Deduplication',
        'description': f'Simple deduplication grouped by {field} field',
        'input_count': input_count,
        'output_count': after_strategy_count,
        'removed': input_count - after_strategy_count,
        'reason': dedup_reason
    }
    
    # Rebuild grouping for log
    from collections import defaultdict
    grouped = defaultdict(list)
    for v in result:
        key = v.get(field, None) if isinstance(v, dict) else None
        grouped[key].append(v)
    
    # Generate modular log also for fallback
    log_content = generate_consolidation_log(
        strategy_report=fallback_report,
        description_filtering_removed=0,
        all_groups=grouped,
        vulnerabilities_input=input_count,
        vulnerabilities_after_strategy=after_strategy_count,
        vulnerabilities_final=after_strategy_count
    )
    
    with open(dedup_log_path, 'w', encoding='utf-8') as f:
        f.write(log_content)
    print(f"[DEDUPLICATION] Deduplication log saved to: {dedup_log_path}")
    return result
def remove_duplicates_by_key(vulnerabilities: list, key: str = "Name", log_path: str = None) -> list:
    """
    Remove vulnerability duplicates based on a specific key.
    If log_path is provided, saves a log of removed duplicates.
    """
    seen = set()
    unique = []
    removed = []
    for v in vulnerabilities:
        val = v.get(key, None) if isinstance(v, dict) else None
        if val is not None and val not in seen:
            seen.add(val)
            unique.append(v)
        else:
            removed.append(v)
    if log_path and removed:
        import json
        with open(log_path, 'w', encoding='utf-8') as f:
            f.write(f"# LOG OF REMOVED DUPLICATES BY KEY '{key}'\n\n")
            for idx, v in enumerate(removed, 1):
                f.write(f"Removed {idx}:\n")
                f.write(json.dumps(v, ensure_ascii=False, indent=2))
                f.write("\n---\n")
    return unique

def consolidate_duplicates_with_logs(vulnerabilities: List[Dict], profile_config: Dict = None):
    """
    Consolida vulnerabilidades removendo duplicatas e mesclando URLs, gerando logs detalhados de removidos e merges.
    Retorna: (final_vulns, removed_vulns, merged_pairs)
    """
    if not vulnerabilities:
        return [], [], []

    # 1. Remove vulnerabilities without valid description
    def has_valid_description(vuln):
        desc = vuln.get("description")
        if not desc:
            return False
        if isinstance(desc, list):
            return any(str(d).strip() for d in desc)
        return bool(str(desc).strip())

    valid_vulns = []
    removed = []
    for v in vulnerabilities:
        if has_valid_description(v):
            valid_vulns.append(v)
        else:
            removed.append(v)

    # 2. Consolidate duplicates using centralized logic
    consolidated = consolidate_vulnerabilities(valid_vulns, profile_config)

    # 3. Generate merged pairs for log (groups of vulnerabilities that were consolidated)
    # For each consolidated group, if there is more than one original vulnerability, consider merge
    # (Simple implementation: groups by consolidation key and compares group size)
    from collections import defaultdict
    merged_pairs = []
    name_field = None
    if consolidated:
        # Detecta campo de chave
        sample = consolidated[0]
        for k in ["name_consolidated", "definition.name", "Name"]:
            if k in sample:
                name_field = k
                break
        if not name_field:
            name_field = "Name"

    group_map = defaultdict(list)
    for v in valid_vulns:
        key = v.get(name_field, '').strip().lower() if name_field else ''
        group_map[key].append(v)

    for group in group_map.values():
        if len(group) > 1:
            merged_pairs.append(group)

    return consolidated, removed, merged_pairs

def consolidate_vulnerabilities(vulnerabilities: List[Dict], profile_config: Dict = None) -> List[Dict]:
    """
    Consolidates vulnerabilities using the detected scanner strategy.
    Modular, extensível e centralizado.
    """
    if not vulnerabilities:
        return []
    # Agrupa por source
    from collections import defaultdict
    by_source = defaultdict(list)
    for vuln in vulnerabilities:
        source = vuln.get('source', 'UNKNOWN')
        by_source[source].append(vuln)
    consolidated = []
    for source, vulns in by_source.items():
        strategy = get_strategy(source)
        if not strategy:
            consolidated.extend(vulns)
            continue
        if not strategy.should_consolidate():
            consolidated.extend(vulns)
            continue
        # Agrupa e consolida por base name/chave
        if source == 'OPENVAS':
            by_key = defaultdict(list)
            for vuln in vulns:
                name = vuln.get('Name', '').strip()
                port = vuln.get('port')
                protocol = vuln.get('protocol')
                if name:
                    key = (name, port, protocol)
                    by_key[key].append(vuln)
            for key, group in by_key.items():
                result = strategy.consolidate_group(group)
                consolidated.extend(result)
        else:
            by_name = defaultdict(list)
            for vuln in vulns:
                name = vuln.get('Name', '').strip()
                if name:
                    base_name = strategy.get_base_name(name)
                    by_name[base_name].append(vuln)
            for base_name, group in by_name.items():
                result = strategy.consolidate_group(group, profile_config)
                consolidated.extend(result)
    return consolidated
